# FLINK SQL MONGODB CONNECTOR

连接器允许将数据写入MongoDB。本文描述了如何设置MongoDB连接器以对MongoDB运行SQL查询。

连接器可以在upsert模式下操作，使用DDL上定义的主键与外部系统交换UPDATE/DELETE消息。

如果在DDL上没有定义主键，则连接器只能以附加模式操作，以便与外部系统交换INSERT消息。

本次发布适用于flink 1.14.X系列的依赖，仅支持sink写入到mongodb.

## Connector Options

|           Option           | Required |              Default              |   Type   |                                                        Description                                                        |
|:--------------------------:|:--------:|:---------------------------------:|:--------:|:-------------------------------------------------------------------------------------------------------------------------:|
|         connector          | required |              (none)               |  String  |                                                          mongodb                                                          |
|            url             | required |              (none)               |  String  |                                         Specifies the connection url of MongoDB.                                          |
|            user            | required |              (none)               |  String  |                                            Specifies the mongodb database user                                            |
|         replicaset         | required |              (none)               |  String  |                                         Specifies the mongodb database replicaset                                         |
|         ignoreNull         | optional |               true                | Boolean  | whether ignore the null value or not.True means ignore the null value." + "we will do not insert the field into document. |
|          password          | required |              (none)               |  String  |                                          Specifies the mongodb database password                                          |
|          database          | required |              (none)               |  String  |                                   `Specifies the database to read or write of MongoDB.`                                   |
|         collection         | required |              (none)               |  String  |                                  `Specifies the collection to read or write of MongoDB.`                                  |
| sink.buffer-flush.max-rows | optional |               1000                | Integer  |                            `Specifies the maximum number of buffered rows per batch request.`                             |
| sink.buffer-flush.interval | optional | 1s or 1000 or 1000ms or 1000milli | Duration |       `Specifies the batch flush interval.`.eg.you can put all kinds of below into it.1s /1000 /1000ms /1000milli``       |
|  sink.delivery-guarantee   | optional |           at-least-once           |  String  |              `Optional delivery guarantee when committing. The exactly-once guarantee is not supported yet.`              |
|      sink.max-retries      | optional |                 3                 | Integer  |                           Specifies the max retry times if writing records to database failed.                            |
|    sink.retry.interval     | optional | 1s or 1000 or 1000ms or 1000milli | Duration |                          you can put all kinds of below into it..eg.1s /1000 /1000ms /1000milli                           |

## How to create a MongoDB table

The MongoDB table can be defined as following:

```sql
-- register a MongoDB table 'users' in Flink SQL
CREATE TABLE MyUserTable (
  _id STRING,
  name STRING,
  age INT,
  status BOOLEAN,
  PRIMARY KEY (_id) NOT ENFORCED
) WITH (
   'connector' = 'mongodb',
   'url' = 'xxx:270,xxx:270,xxx:270',
   'database' = 'my_db',
   'collection' = 'users',
   'user'='xx',
   'password' = 'xx',
   'replicaset' = 'xx',
   'database' = 'tdp_main',
   'collection' = 'test',
   'ignoreNull'='false',
   'sink.buffer-flush.interval'='8s',
   'sink.buffer-flush.max-rows'='1000'
);

-- write data into the MongoDB table from the other table "T"
INSERT INTO MyUserTable
SELECT _id, name, age, status FROM T;

```



## Data Type Mapping

The field data type mappings from MongoDB BSON types to Flink SQL data types are listed in the following table.

| [MongoDB BSON type](https://www.mongodb.com/docs/manual/reference/bson-types/#bson-types) | [Flink SQL type](https://nightlies.apache.org/flink/flink-docs-release-1.16/docs/dev/table/types/) |
|:------------------------------------------------------------------------------------------|:---------------------------------------------------------------------------------------------------|
| [MongoDB BSON type](https://www.mongodb.com/docs/manual/reference/bson-types/#bson-types) | [Flink SQL type](https://nightlies.apache.org/flink/flink-docs-release-1.16/docs/dev/table/types/) |
| `ObjectId`                                                                                | `STRING`                                                                                           |
| `String`                                                                                  | `STRING`                                                                                           |
| `Boolean`                                                                                 | `BOOLEAN`                                                                                          |
| `Binary`                                                                                  | `BINARY` `VARBINARY`                                                                               |
| `Int32`                                                                                   | `INTEGER`                                                                                          |
| Int16                                                                                     | `SMALLINT`                                                                                         |
| Byte                                                                                      | `TINYINT`                                                                                          |
| `FLOAT`                                                                                   | `FLOAT`                                                                                            |
| `Int64`                                                                                   | `BIGINT`                                                                                           |
| `Double`                                                                                  | `DOUBLE`                                                                                           |
| `Decimal128`                                                                              | `DECIMAL`                                                                                          |
| `DateTime`                                                                                | `TIMESTAMP_LTZ(3)`                                                                                 |
| `Timestamp`                                                                               | `TIMESTAMP_LTZ(0)`                                                                                 |
| `Document`                                                                                | `ROW`                                                                                              |
| `Array`                                                                                   | `ARRAY`                                                                                            |