/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.flink.connector.mongodb.table;

import org.apache.flink.connector.mongodb.sink.config.MongoConfiguration;
import org.apache.flink.connector.mongodb.sink.config.MongoConnectionOptions;
import org.apache.flink.connector.mongodb.sink.config.MongoWriteOptions;
import java.util.HashSet;
import java.util.Set;
import org.apache.flink.annotation.Internal;
import org.apache.flink.configuration.ConfigOption;
import org.apache.flink.table.catalog.ResolvedSchema;
import org.apache.flink.table.connector.sink.DynamicTableSink;
import org.apache.flink.table.factories.DynamicTableSinkFactory;
import org.apache.flink.table.factories.FactoryUtil;

import static org.apache.flink.table.factories.FactoryUtil.SINK_PARALLELISM;


/**
 * @author weitianpei
 * <p>
 * This MongoDynamicTableFactory is used for flink 1.14.X series.At present, it is
 * only support sink.
 */
@Internal
public class MongoDynamicTableFactory implements DynamicTableSinkFactory {

    /**
     * 标识，flink创建表的时候，用于填写connector类型
     */
    public static final String IDENTIFIER = "mongodb";

    @Override
    public String factoryIdentifier() {
        return IDENTIFIER;
    }

    @Override
    public Set<ConfigOption<?>> requiredOptions() {
        final Set<ConfigOption<?>> requiredOptions = new HashSet<>();
        requiredOptions.add(MongoConnectorOptions.URL);
        requiredOptions.add(MongoConnectorOptions.DATABASE);
        requiredOptions.add(MongoConnectorOptions.COLLECTION);
        requiredOptions.add(MongoConnectorOptions.USER);
        requiredOptions.add(MongoConnectorOptions.PASSWORD);
        requiredOptions.add(MongoConnectorOptions.REPLICASET);
        return requiredOptions;
    }

    @Override
    public Set<ConfigOption<?>> optionalOptions() {
        final Set<ConfigOption<?>> optionalOptions = new HashSet<>();

        optionalOptions.add(MongoConnectorOptions.IGNORE_NULL_VALUE);
        optionalOptions.add(MongoConnectorOptions.BUFFER_FLUSH_MAX_ROWS);
        optionalOptions.add(MongoConnectorOptions.BUFFER_FLUSH_INTERVAL);
        optionalOptions.add(MongoConnectorOptions.DELIVERY_GUARANTEE);
        optionalOptions.add(MongoConnectorOptions.SINK_MAX_RETRIES);
        optionalOptions.add(MongoConnectorOptions.SINK_RETRY_INTERVAL);
        optionalOptions.add(SINK_PARALLELISM);
        return optionalOptions;
    }


    @Override
    public DynamicTableSink createDynamicTableSink(Context context) {
        final FactoryUtil.TableFactoryHelper helper =
                FactoryUtil.createTableFactoryHelper(this, context);

        MongoConfiguration config = new MongoConfiguration(helper.getOptions());
        helper.validate();

        ResolvedSchema schema = context.getCatalogTable().getResolvedSchema();
        boolean isUpsert = schema.getPrimaryKey().isPresent();

        return new MongoDynamicTableSink(
                getConnectionOptions(config),
                getWriteOptions(config),
                config.getSinkParallelism(),
                isUpsert,
                schema
        );
    }


    private static MongoConnectionOptions getConnectionOptions(MongoConfiguration configuration) {
        return MongoConnectionOptions.builder()
                .setUrl(configuration.getUri())
                .setDatabase(configuration.getDatabase())
                .setCollection(configuration.getCollection())
                .setUser(configuration.getUser())
                .setPassword(configuration.getPassword())
                .setReplicated(configuration.getReplicaset())
                .setIgnoreNull(configuration.getIgnoreNull())
                .build();
    }


    private static MongoWriteOptions getWriteOptions(MongoConfiguration configuration) {
        return MongoWriteOptions.builder()
                .setBatchSize(configuration.getBufferFlushMaxRows())
                .setBatchIntervalMs(configuration.getBufferFlushIntervalMs())
                .setMaxRetries(configuration.getSinkMaxRetries())
                .setRetryIntervalMs(configuration.getSinkRetryIntervalMs())
                .setDeliveryGuarantee(configuration.getDeliveryGuarantee())
                .build();
    }
}
