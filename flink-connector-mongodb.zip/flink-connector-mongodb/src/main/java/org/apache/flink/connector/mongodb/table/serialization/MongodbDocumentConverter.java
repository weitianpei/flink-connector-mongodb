package org.apache.flink.connector.mongodb.table.serialization;

import org.bson.Document;

import java.io.Serializable;

public interface MongodbDocumentConverter<T> extends Serializable {

    Document convertToDocument(T row);

}
