/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.flink.connector.mongodb.sink.config;

import java.util.Objects;
import javax.annotation.Nullable;
import org.apache.flink.annotation.Internal;
import org.apache.flink.configuration.ReadableConfig;
import org.apache.flink.connector.base.DeliveryGuarantee;

import static org.apache.flink.connector.mongodb.table.MongoConnectorOptions.BUFFER_FLUSH_INTERVAL;
import static org.apache.flink.connector.mongodb.table.MongoConnectorOptions.BUFFER_FLUSH_MAX_ROWS;
import static org.apache.flink.connector.mongodb.table.MongoConnectorOptions.COLLECTION;
import static org.apache.flink.connector.mongodb.table.MongoConnectorOptions.DATABASE;
import static org.apache.flink.connector.mongodb.table.MongoConnectorOptions.DELIVERY_GUARANTEE;
import static org.apache.flink.connector.mongodb.table.MongoConnectorOptions.IGNORE_NULL_VALUE;
import static org.apache.flink.connector.mongodb.table.MongoConnectorOptions.PASSWORD;
import static org.apache.flink.connector.mongodb.table.MongoConnectorOptions.REPLICASET;
import static org.apache.flink.connector.mongodb.table.MongoConnectorOptions.SINK_MAX_RETRIES;
import static org.apache.flink.connector.mongodb.table.MongoConnectorOptions.SINK_RETRY_INTERVAL;
import static org.apache.flink.connector.mongodb.table.MongoConnectorOptions.URL;
import static org.apache.flink.connector.mongodb.table.MongoConnectorOptions.USER;
import static org.apache.flink.table.factories.FactoryUtil.SINK_PARALLELISM;

/**
 * MongoDB configuration.
 */
@Internal
public class MongoConfiguration {

    private final ReadableConfig config;

    public MongoConfiguration(ReadableConfig config) {
        this.config = config;
    }

    // -----------------------------------Connection Config----------------------------------------
    public String getUri() {
        return config.get(URL);
    }

    public String getDatabase() {
        return config.get(DATABASE);
    }

    public String getCollection() {
        return config.get(COLLECTION);
    }

    public String getUser() {
        return config.get(USER);
    }

    public String getPassword() {
        return config.get(PASSWORD);
    }

    public String getReplicaset() {
        return config.get(REPLICASET);
    }

    public Boolean getIgnoreNull() {
        return config.get(IGNORE_NULL_VALUE);
    }


    // -----------------------------------Write Config------------------------------------------
    public int getBufferFlushMaxRows() {
        return config.get(BUFFER_FLUSH_MAX_ROWS);
    }

    public long getBufferFlushIntervalMs() {
        return config.get(BUFFER_FLUSH_INTERVAL).toMillis();
    }

    public int getSinkMaxRetries() {
        return config.get(SINK_MAX_RETRIES);
    }

    public long getSinkRetryIntervalMs() {
        return config.get(SINK_RETRY_INTERVAL).toMillis();
    }

    public DeliveryGuarantee getDeliveryGuarantee() {
        return config.get(DELIVERY_GUARANTEE);
    }

    @Nullable
    public Integer getSinkParallelism() {
        return config.getOptional(SINK_PARALLELISM).orElse(null);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        MongoConfiguration that = (MongoConfiguration) o;
        return Objects.equals(config, that.config);
    }

    @Override
    public int hashCode() {
        return Objects.hash(config);
    }
}
