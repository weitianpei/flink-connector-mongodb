/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.flink.connector.mongodb.table.serialization;

import org.apache.flink.connector.mongodb.sink.serializer.MongoSerializationSchema;
import org.apache.flink.connector.mongodb.table.MongoDynamicTableFactory;
import org.apache.flink.connector.mongodb.table.MongoDynamicTableSink;
import com.mongodb.client.model.DeleteOneModel;
import com.mongodb.client.model.InsertOneModel;
import com.mongodb.client.model.UpdateOneModel;
import com.mongodb.client.model.UpdateOptions;
import com.mongodb.client.model.WriteModel;
import org.apache.flink.annotation.Internal;
import org.apache.flink.connector.mongodb.sink.config.MongoConstants;
import org.apache.flink.table.api.TableException;
import org.apache.flink.table.connector.ChangelogMode;
import org.apache.flink.table.data.RowData;
import org.apache.flink.table.factories.DynamicTableFactory;
import org.apache.flink.types.RowKind;
import org.bson.Document;

/**
 * The serialization schema for flink {@link RowData} to serialize records into MongoDB.
 * @author weitianpei 20230720
 */
@Internal
public class MongoRowDataSerializationSchema implements MongoSerializationSchema<RowData> {

    private final MongodbDocumentConverter<RowData> rowDataToMongoDocumentConverter;

    public MongoRowDataSerializationSchema(MongodbDocumentConverter<RowData> rowDataToMongoDocumentConverter) {
        this.rowDataToMongoDocumentConverter = rowDataToMongoDocumentConverter;
    }

    public WriteModel<Document> processUpsert(RowData row) {
        final Document document = rowDataToMongoDocumentConverter.convertToDocument(row);
        final Object key = document.get(MongoConstants.ID_FIELD);

        if (key != null) {
            Document filter = new Document(MongoConstants.ID_FIELD, key);
            // _id is immutable so we remove it here to prevent exception.
            document.remove(MongoConstants.ID_FIELD);
            Document update = new Document("$set", document);
            return new UpdateOneModel<>(filter, update, new UpdateOptions().upsert(true));
        } else {
            return new InsertOneModel<>(document);
        }
    }

    /**
     *
     * @param row rowData
     * @return WriteModel<Document>
     */
    private WriteModel<Document> processDelete(RowData row) {
        final Document document = rowDataToMongoDocumentConverter.convertToDocument(row);
        final Object key = document.get(MongoConstants.ID_FIELD);

        Document filter = new Document(MongoConstants.ID_FIELD, key);
        return new DeleteOneModel<>(filter);
    }


    /**
     * 当上游流rowKind 为{@link RowKind#INSERT} 或者 {@link RowKind#UPDATE_AFTER}时，
     * 返回 {@link MongoRowDataSerializationSchema#processUpsert(RowData)}。
     * 当上游流rowKind为{@link RowKind#UPDATE_BEFORE} or {@link RowKind#DELETE}时，
     * 返回 {@link MongoRowDataSerializationSchema#processDelete(RowData)}.
     * 其余类型抛异常。
     * <p></p>
     *<p>也许你会问，当我们在flinkSql中创建mongoDb表时，未指定primaryKey,会出现什么情况呢。
     * {@link MongoDynamicTableFactory#createDynamicTableSink(DynamicTableFactory.Context)}
     * 中通过pk是否存在计算出upsert的值。接着{@link MongoDynamicTableSink#getChangelogMode(ChangelogMode)}
     * 来判断sink端接受什么样类型的流。
     *
     * <p></p>当我们不指定primaryKey(以下简称PK)时，那程序只接受{@link RowKind#INSERT}流。
     * 当pk存在时，则接受{@link RowKind#UPDATE_AFTER},{@link RowKind#DELETE},{@link RowKind#INSERT}三种类型。
     * <p>
     * 接下来本方法根据rowKind来处理数据。
     *</p>
     *
     * @param element RowData
     * @return WriteModel<Document>
     */
    @Override
    public WriteModel<Document> serialize(RowData element) {
        switch (element.getRowKind()) {
            case INSERT:
            case UPDATE_AFTER:
                return processUpsert(element);
            case UPDATE_BEFORE:
            case DELETE:
                return processDelete(element);
            default:
                throw new TableException("Unsupported message kind: " + element.getRowKind());
        }
    }
}
