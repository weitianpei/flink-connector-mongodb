package org.apache.flink.connector.mongodb.table.serialization;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import org.apache.flink.connector.mongodb.sink.config.MongoConstants;
import org.apache.flink.table.data.ArrayData;
import org.apache.flink.table.data.DecimalData;
import org.apache.flink.table.data.MapData;
import org.apache.flink.table.data.RowData;
import org.apache.flink.table.data.TimestampData;
import org.apache.flink.table.types.DataType;
import org.apache.flink.table.types.logical.ArrayType;
import org.apache.flink.table.types.logical.LogicalType;
import org.apache.flink.table.types.logical.LogicalTypeFamily;
import org.apache.flink.table.types.logical.LogicalTypeRoot;
import org.apache.flink.table.types.logical.MapType;
import org.apache.flink.table.types.logical.RowType;
import org.bson.Document;
import org.bson.types.Decimal128;

import static org.apache.flink.util.Preconditions.checkNotNull;

/**
 * It is a converter for changing rowData into MongoDocument.
 * @author weitianpei
 */
public class RowDataToMongoDocumentConverter implements MongodbDocumentConverter<RowData> {

    /**
     * rowData 中primaryKey 对应的列名。primaryKey可以为组合键.
     */
    private final List<String> keyNames;

    /**
     * 是否忽略rowData中字段值为空值的情况。如果忽略空字段，我们不会往mongodb插入这样的字段。
     */
    private final boolean ignoreNull;

    /**
     * rowData对应的物理化字段数据类型
     */
    private final DataType physicalRowDataType;


    public RowDataToMongoDocumentConverter(List<String> keyNames, DataType physicalRowDataType, boolean ignoreNull) {
        this.keyNames = keyNames;
        this.ignoreNull = ignoreNull;
        this.physicalRowDataType = physicalRowDataType;
    }

    /**
     * 将传入的rowData转换为Document.
     *
     * @param rowData rowData
     * @return Document
     */
    @Override
    public Document convertToDocument(RowData rowData) {
        Document doc = (Document) flinkType2JavaType(rowData, physicalRowDataType.getLogicalType());

        //insert _id into document.
        Object primaryKeyValue = getPrimaryKeyValue(doc, keyNames);
        if (Objects.nonNull(primaryKeyValue)) {
            assert doc != null;
            doc.put(MongoConstants.ID_FIELD, primaryKeyValue);
        }
        return doc;
    }


    /**
     * <p>primaryKey这里可以为单字段，也可以为组合字段。不同的类型返回的结果也会不同。以下举例说明：
     * <p>当primaryKey为单字段时，仅返回字段对应的值，是一个Object类型。
     * <p>当primaryKey为组合字段时，返回Document,如：{"col1":"v1","col2":"v2"}。
     *
     * @param document 已经计算好的document
     * @param keyNames primaryKey的列名列表
     * @return Object
     */
    private Object getPrimaryKeyValue(Document document, List<String> keyNames) {
        if (keyNames.size() > 1) {
            Document pkDoc = new Document();
            keyNames.forEach(keyName ->
                    pkDoc.put(keyName, checkNotNull(document.get(keyName), String.format("The primary key %s is null", keyName)))
            );
            return pkDoc;
        } else if (keyNames.size() == 1) {
            return checkNotNull(document.get(keyNames.get(0)), String.format("The value of the primary key is null.Col is %s", keyNames.get(0)));
        } else {
            return null;
        }
    }

    /**
     * <p>将传入的rowData进行解析，递归的形式去对每个字段进行解析，字段支持嵌套字段，例如row,array,
     * map等复杂类型。
     *
     * <p>特别说明，针对array<T> 类型，array中的T必须指定一种类型。针对Map<K,V>：K必须为STRING。
     * 或者VARCHAR,CHARACTER。否则会抛不支持异常。
     *<p>封装好之后，返回Document类型
     * <p>
     * @param value       rowData
     * @param logicalType logicalType
     * @return (Document) object
     */
    private Object flinkType2JavaType(Object value, LogicalType logicalType) {
        if (value == null || LogicalTypeRoot.NULL.equals(logicalType.getTypeRoot())) {
            if (logicalType.isNullable()) {
                return null;
            } else {
                throw new IllegalArgumentException(
                        "The column type is <"
                                + logicalType
                                + ">, but a null value is being written into it");
            }
        } else {
            switch (logicalType.getTypeRoot()) {
                case CHAR:
                case VARCHAR:
                    return value.toString();
                case DECIMAL:
                    return new Decimal128(((DecimalData) value).toBigDecimal());
                case ARRAY:
                    int size = ((ArrayData) value).size();
                    LogicalType elementType = ((ArrayType) logicalType).getElementType();
                    ArrayData.ElementGetter elementGetter = ArrayData.createElementGetter(elementType);
                    ArrayList<Object> arrayList = new ArrayList<>();
                    for (int i = 0; i < size; i++) {
                        arrayList.add(flinkType2JavaType(elementGetter.getElementOrNull((ArrayData) value, i), elementType));
                    }
                    return arrayList;
                case MAP:
                    MapData mapData = (MapData) value;
                    final LogicalType valueType = ((MapType) logicalType).getValueType();
                    final LogicalType keyType = ((MapType) logicalType).getKeyType();

                    if (!keyType.getTypeRoot().getFamilies().contains(LogicalTypeFamily.CHARACTER_STRING)) {
                        throw new UnsupportedOperationException(
                                "MongoDB doesn't support non-string as key type of map. "
                                        + "The type is: "
                                        + keyType.asSummaryString());
                    }

                    final ArrayData.ElementGetter valueGetter = ArrayData.createElementGetter(valueType);
                    final ArrayData keyArray = ((MapData) value).keyArray();
                    final ArrayData valueArray = ((MapData) value).valueArray();
                    final Document document = new Document();

                    for (int i = 0; i < (mapData.size()); i++) {
                        final String key = keyArray.getString(i).toString();
                        final Object v = flinkType2JavaType(valueGetter.getElementOrNull(valueArray, i), valueType);
                        if (Objects.nonNull(v)) {
                            document.put(key, v);
                        } else if (!ignoreNull) {
                            document.put(key, null);
                        } else {
                            //do nothing
                        }
                    }
                    return document;
                case ROW:
                    RowType rowType = ((RowType) logicalType);
                    final LogicalType[] fieldTypes =
                            rowType.getFields().stream()
                                    .map(RowType.RowField::getType)
                                    .toArray(LogicalType[]::new);
                    final int fieldCount = rowType.getFieldCount();
                    RowData rowData = ((RowData) value);

                    final RowData.FieldGetter[] fieldGetters = new RowData.FieldGetter[fieldCount];

                    for (int j = 0; j < fieldCount; j++) {
                        fieldGetters[j] = RowData.createFieldGetter(fieldTypes[j], j);
                    }

                    final Document rowDoc = new Document();
                    for (int k = 0; k < fieldCount; k++) {
                        String fieldName = rowType.getFieldNames().get(k);
                        Object fieldValue = fieldGetters[k].getFieldOrNull(rowData);

                        if (Objects.nonNull(fieldValue)) {
                            rowDoc.append(fieldName, flinkType2JavaType(fieldValue, rowType.getTypeAt(k)));
                        } else {
                            if (!ignoreNull) {
                                rowDoc.append(fieldName, null);
                            } else {
                                //do nothing.
                            }
                        }
                    }
                    return rowDoc;
                case BOOLEAN:
                case BIGINT:
                case INTERVAL_DAY_TIME:
                case TINYINT:
                case SMALLINT:
                case INTEGER:
                case DATE:
                case TIME_WITHOUT_TIME_ZONE:
                case INTERVAL_YEAR_MONTH:
                case DOUBLE:
                case FLOAT:
                case BINARY:
                case VARBINARY:
                    return value;
                case TIMESTAMP_WITH_LOCAL_TIME_ZONE:
                case TIMESTAMP_WITHOUT_TIME_ZONE:
                    return ((TimestampData) value).getMillisecond();
                case NULL:
                case MULTISET:
                case RAW:
                case TIMESTAMP_WITH_TIME_ZONE:
                default:
                    throw new UnsupportedOperationException("Unsupported type:" + logicalType);
            }
        }
    }

}
