/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.flink.connector.mongodb.table;

import org.apache.flink.connector.mongodb.table.serialization.MongoRowDataSerializationSchema;
import org.apache.flink.connector.mongodb.MongodbSinkFunction;
import org.apache.flink.connector.mongodb.table.serialization.RowDataToMongoDocumentConverter;
import org.apache.flink.connector.mongodb.sink.config.MongoConnectionOptions;
import org.apache.flink.connector.mongodb.sink.config.MongoWriteOptions;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import javax.annotation.Nullable;
import org.apache.flink.annotation.Internal;
import org.apache.flink.connector.base.DeliveryGuarantee;
import org.apache.flink.table.catalog.ResolvedSchema;
import org.apache.flink.table.catalog.UniqueConstraint;
import org.apache.flink.table.connector.ChangelogMode;
import org.apache.flink.table.connector.sink.DynamicTableSink;
import org.apache.flink.table.connector.sink.SinkFunctionProvider;
import org.apache.flink.table.data.RowData;
import org.apache.flink.table.types.DataType;

import static org.apache.flink.util.Preconditions.checkNotNull;

/**
 * A {@link DynamicTableSink} for MongoDB.
 */
@Internal
public class MongoDynamicTableSink implements DynamicTableSink {

    private final MongoConnectionOptions mongoConnectionOptions;
    private final MongoWriteOptions mongoWriteOptions;
    @Nullable
    private final Integer parallelism;
    private final boolean isUpsert;
    private final ResolvedSchema resolvedSchema;

    public MongoDynamicTableSink(
            MongoConnectionOptions mongoConnectionOptions,
            MongoWriteOptions mongoWriteOptions,
            @Nullable Integer parallelism,
            boolean isUpsert,
            ResolvedSchema resolvedSchema
    ) {
        this.mongoConnectionOptions = checkNotNull(mongoConnectionOptions);
        this.mongoWriteOptions = checkNotNull(mongoWriteOptions);
        this.parallelism = parallelism;
        this.isUpsert = isUpsert;
        this.resolvedSchema = checkNotNull(resolvedSchema);
    }

    @Override
    public ChangelogMode getChangelogMode(ChangelogMode requestedMode) {
        if (isUpsert) {
            return ChangelogMode.upsert();
        } else {
            return ChangelogMode.insertOnly();
        }
    }

    @Override
    public SinkRuntimeProvider getSinkRuntimeProvider(Context context) {
        List<String> keyFields = resolvedSchema.getPrimaryKey()
                .map(UniqueConstraint::getColumns)
                .orElse(new ArrayList<>());
        DataType physicalRowDataType = resolvedSchema.toPhysicalRowDataType();

        MongodbSinkFunction<RowData> sinkFunction = new MongodbSinkFunction<>(
                new MongoRowDataSerializationSchema(new RowDataToMongoDocumentConverter(keyFields, physicalRowDataType, mongoConnectionOptions.isIgnoreNull())),
                mongoConnectionOptions,
                Objects.equals(mongoWriteOptions.getDeliveryGuarantee(), DeliveryGuarantee.AT_LEAST_ONCE.name()),
                mongoWriteOptions);

        return SinkFunctionProvider.of(sinkFunction, parallelism);
    }

    @Override
    public MongoDynamicTableSink copy() {
        return new MongoDynamicTableSink(
                mongoConnectionOptions,
                mongoWriteOptions,
                parallelism,
                isUpsert,
                resolvedSchema
        );
    }

    @Override
    public String asSummaryString() {
        return "MongoDB";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        MongoDynamicTableSink that = (MongoDynamicTableSink) o;
        return Objects.equals(mongoConnectionOptions, that.mongoConnectionOptions)
                && Objects.equals(mongoWriteOptions, that.mongoWriteOptions)
                && Objects.equals(parallelism, that.parallelism)
                && Objects.equals(isUpsert, that.isUpsert)
                && Objects.equals(resolvedSchema, that.resolvedSchema);
    }

    @Override
    public int hashCode() {
        return Objects.hash(
                mongoConnectionOptions, mongoWriteOptions, parallelism, isUpsert, resolvedSchema);
    }
}
