package org.apache.flink.connector.mongodb;

import org.apache.flink.connector.mongodb.sink.config.MongoConnectionOptions;
import org.apache.flink.connector.mongodb.sink.config.MongoWriteOptions;
import org.apache.flink.connector.mongodb.sink.serializer.MongoSerializationSchema;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.MongoException;
import com.mongodb.client.model.WriteModel;
import java.io.IOException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import org.apache.flink.api.common.accumulators.IntCounter;
import org.apache.flink.api.common.functions.RuntimeContext;
import org.apache.flink.api.common.functions.util.ListCollector;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.runtime.state.FunctionInitializationContext;
import org.apache.flink.runtime.state.FunctionSnapshotContext;
import org.apache.flink.streaming.api.checkpoint.CheckpointedFunction;
import org.apache.flink.streaming.api.functions.sink.RichSinkFunction;
import org.apache.flink.util.Collector;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * <p>Universal MongodbSinkFunction,You can create a variety of custom functions
 * by RichSinkFunction.
 * <p>
 *
 * <p>Here,we can define generic mongoSerializationSchema to process rowData into
 * Document data.
 *
 * @param <T>
 * @author weitianpei 2023.07.20
 */
public class MongodbSinkFunction<T> extends RichSinkFunction<T> implements CheckpointedFunction {

    private static final Logger LOG = LoggerFactory.getLogger(MongodbSinkFunction.class);
    private final String url;
    private final String user;
    private final String password;
    private final String replicaSet;
    private final String database;
    private final String collection;
    private final boolean flushOnCheckpoint;
    private final MongoWriteOptions writeOptions;
    private final List<WriteModel<Document>> bulkRequests = new ArrayList<>();
    private transient Collector<WriteModel<Document>> collector;
    private transient MongoClient mongoClient;
    private final MongoSerializationSchema<T> mongoSerializationSchema;
    private final IntCounter numRecordsOut = new IntCounter();
    private volatile long lastSendTime = 0L;


    public MongodbSinkFunction(MongoSerializationSchema<T> mongoSerializationSchema, MongoConnectionOptions mongoConnectionOptions, Boolean flushOnCheckpoint, MongoWriteOptions writeOptions) {
        this.url = mongoConnectionOptions.getUrl();
        this.user = mongoConnectionOptions.getUser();
        this.password = mongoConnectionOptions.getPassword();
        this.database = mongoConnectionOptions.getDatabase();
        this.collection = mongoConnectionOptions.getCollection();
        this.replicaSet = mongoConnectionOptions.getReplicaSet();
        this.mongoSerializationSchema = mongoSerializationSchema;
        this.writeOptions = writeOptions;
        this.collector = new ListCollector<>(this.bulkRequests);
        this.flushOnCheckpoint = flushOnCheckpoint;
    }


    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);
        this.collector = new ListCollector<>(this.bulkRequests);

        RuntimeContext ctx = getRuntimeContext();
        ctx.addAccumulator("counter", numRecordsOut);
        String conStr = "mongodb://{0}:{1}@{2}/{3}?authSource={4}&replicaSet={5}&connectTimeoutMS=120000";
        MongoClientURI clientURI = new MongoClientURI(MessageFormat.format(conStr, user, password, url, database, "admin", replicaSet));
        mongoClient = new MongoClient(clientURI);
    }

    @Override
    public void snapshotState(FunctionSnapshotContext functionSnapshotContext) throws Exception {
        while (!bulkRequests.isEmpty() && (flushOnCheckpoint)) {
            doBulkWrite();
        }
    }

    @Override
    public void initializeState(FunctionInitializationContext functionInitializationContext) {
        /*
          do nothing here.
         */
    }

    /**
     * When a data comes in,We will temporarily collect data to collector.
     * When the collected data exceeds the `batchSize` parameter, or it exceeds
     * the `bulkFlushInterval`, we willbulk write the data.
     *
     * @param data    The input record.
     * @param context Additional context about the input record.
     * @throws Exception exception
     */
    @Override
    public void invoke(T data, Context context) throws Exception {
        WriteModel<Document> writeModel = mongoSerializationSchema.serialize(data);
        this.numRecordsOut.add(1);
        collector.collect(writeModel);

        if (isOverMaxBatchSizeLimit() || isOverMaxBatchIntervalLimit()) {
            doBulkWrite();
        }
    }

    @Override
    public void close() {
        if (this.numRecordsOut.getLocalValue() > 0) {
            try {
                doBulkWrite();
            } catch (Exception e) {
                LOG.warn("Writing records to mongoDB failed.", e);
                throw new RuntimeException("Writing records to mongoDB failed.", e);
            }
        }
        mongoClient.close();
    }

    /**
     * Write data to mongodb in batches.
     *
     * @throws IOException ioexception
     */
    void doBulkWrite() throws IOException {
        if (bulkRequests.isEmpty()) {
            // no records to write
            return;
        }

        int maxRetries = writeOptions.getMaxRetries();
        long retryIntervalMs = writeOptions.getRetryIntervalMs();

        for (int i = 0; i <= maxRetries; i++) {
            try {
                lastSendTime = System.currentTimeMillis();
                mongoClient
                        .getDatabase(database)
                        .getCollection(collection, Document.class)
                        .bulkWrite(bulkRequests);
                bulkRequests.clear();
                numRecordsOut.resetLocal();
                break;
            } catch (MongoException e) {
                LOG.debug("Bulk Write to MongoDB failed, retry times = {}", i, e);
                if (i >= maxRetries) {
                    LOG.error("Bulk Write to MongoDB failed", e);
                    throw new IOException(e);
                }
                try {
                    Thread.sleep(retryIntervalMs * (i + 1));
                } catch (InterruptedException ex) {
                    Thread.currentThread().interrupt();
                    throw new IOException(
                            "Unable to flush; interrupted while doing another attempt", e);
                }
            }
        }
    }

    /**
     * Check whether the parameter value is exceeded.
     *
     * @return true or false
     */
    private boolean isOverMaxBatchSizeLimit() {
        int bulkActions = writeOptions.getBatchSize();
        return bulkActions != -1 && bulkRequests.size() >= bulkActions;
    }

    /**
     * Check whether the parameter value is exceeded.
     *
     * @return true or false
     */
    private boolean isOverMaxBatchIntervalLimit() {
        long bulkFlushInterval = writeOptions.getBatchIntervalMs();
        long lastSentInterval = System.currentTimeMillis() - lastSendTime;
        return bulkFlushInterval != -1 && lastSentInterval >= bulkFlushInterval;
    }

}
