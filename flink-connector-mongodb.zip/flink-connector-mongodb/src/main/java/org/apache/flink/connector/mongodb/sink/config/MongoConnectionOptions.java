/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.flink.connector.mongodb.sink.config;

import java.io.Serializable;
import java.util.Objects;
import org.apache.flink.annotation.PublicEvolving;

import static org.apache.flink.util.Preconditions.checkNotNull;

/**
 * The connection configuration class for MongoDB.
 */
@PublicEvolving
public class MongoConnectionOptions implements Serializable {

    private final String url;
    private final String database;
    private final String collection;
    private final String user;
    private final String password;
    private final String replicaSet;
    private final boolean ignoreNull;

    public boolean isIgnoreNull() {
        return ignoreNull;
    }

    public String getUrl() {
        return url;
    }

    public String getDatabase() {
        return database;
    }

    public String getCollection() {
        return collection;
    }

    public String getUser() {
        return user;
    }

    public String getPassword() {
        return password;
    }

    public String getReplicaSet() {
        return replicaSet;
    }


    private MongoConnectionOptions(String url, String database, String collection, String user, String password, String replicaSet, boolean ignoreNull) {
        this.url = checkNotNull(url);
        this.database = checkNotNull(database);
        this.collection = checkNotNull(collection);
        this.user = checkNotNull(user);
        this.password = checkNotNull(password);
        this.replicaSet = checkNotNull(replicaSet);
        this.ignoreNull = ignoreNull;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        MongoConnectionOptions that = (MongoConnectionOptions) o;
        return Objects.equals(url, that.url)
                && Objects.equals(database, that.database)
                && Objects.equals(collection, that.collection)
                && Objects.equals(ignoreNull, that.ignoreNull);
    }

    @Override
    public int hashCode() {
        return Objects.hash(url, database, collection);
    }

    public static MongoConnectionOptionsBuilder builder() {
        return new MongoConnectionOptionsBuilder();
    }

    /**
     * Builder for {@link MongoConnectionOptions}.
     */
    @PublicEvolving
    public static class MongoConnectionOptionsBuilder {
        private String database;
        private String collection;
        private String url;
        private String user;
        private String password;
        private String replicaSet;
        private Boolean ignoreNull = true;


        private MongoConnectionOptionsBuilder() {
        }

        /**
         * Sets the password of MongoDB.
         *
         * @param password the user of the  MongoDB.
         * @return this builder
         */
        public MongoConnectionOptionsBuilder setPassword(String password) {
            this.password = checkNotNull(password, "The password of MongoDB must not be null");
            return this;
        }


        /**
         * Sets the replicaSet of MongoDB.
         *
         * @param replicaSet the user of the  MongoDB.
         * @return this builder
         */
        public MongoConnectionOptionsBuilder setReplicated(String replicaSet) {
            this.replicaSet = checkNotNull(replicaSet, "The replicaSet of MongoDB must not be null");
            return this;
        }


        /**
         * Sets the user of MongoDB.
         *
         * @param user the user of the  MongoDB.
         * @return this builder
         */
        public MongoConnectionOptionsBuilder setUser(String user) {
            this.user = checkNotNull(user, "The user of MongoDB must not be null");
            return this;
        }


        /**
         * Sets the url of MongoDB.
         *
         * @param url the url of the  MongoDB.
         * @return this builder
         */
        public MongoConnectionOptionsBuilder setUrl(String url) {
            this.url = checkNotNull(url, "The database of MongoDB must not be null");
            return this;
        }


        /**
         * Sets the database of MongoDB.
         *
         * @param database the database to sink of MongoDB.
         * @return this builder
         */
        public MongoConnectionOptionsBuilder setDatabase(String database) {
            this.database = checkNotNull(database, "The database of MongoDB must not be null");
            return this;
        }

        /**
         * Sets the collection of MongoDB.
         *
         * @param collection the collection to sink of MongoDB.
         * @return this builder
         */
        public MongoConnectionOptionsBuilder setCollection(String collection) {
            this.collection =
                    checkNotNull(collection, "The collection of MongoDB must not be null");
            return this;
        }

        /**
         * if  to ignore the empty value or not.
         *
         * @param ignoreNull the collection to sink of MongoDB.
         * @return this builder
         */
        public MongoConnectionOptionsBuilder setIgnoreNull(Boolean ignoreNull) {
            this.ignoreNull = ignoreNull;
            return this;
        }

        /**
         * Build the {@link MongoConnectionOptions}.
         *
         * @return a MongoConnectionOptions with the settings made for this builder.
         */
        public MongoConnectionOptions build() {
            return new MongoConnectionOptions(url, database, collection, user, password, replicaSet, ignoreNull);
        }
    }
}
